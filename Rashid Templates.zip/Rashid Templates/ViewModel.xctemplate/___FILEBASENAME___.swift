// ___FILEBASENAMEASIDENTIFIER___
// Created by ___FULLUSERNAME___ on ___DATE___.
// Email:- rashid.latif93@gmail.com
// https://stackoverflow.com/users/10383865/rashid-latif
// https://github.com/rashidlatif55

import UIKit

protocol ___FILEBASENAMEASIDENTIFIER___Delegate {
    func didReceiveAPIError(message: String)
}

class ___FILEBASENAMEASIDENTIFIER___ {
   
    // MARK: - Variables
    var delegate:___FILEBASENAMEASIDENTIFIER___Delegate!
    
    lazy var viewModel:___FILEBASENAMEASIDENTIFIER___ = {
        let vm = ___FILEBASENAMEASIDENTIFIER___()
        vm.delegate = self
        return vm
    }()
    
}

// MARK: - API calls
extension ___FILEBASENAMEASIDENTIFIER___ {
    
}
 
