// ___FILEBASENAMEASIDENTIFIER___
// Created by ___FULLUSERNAME___ on ___DATE___.
// Email:- rashid.latif93@gmail.com
// https://stackoverflow.com/users/10383865/rashid-latif
// https://github.com/rashidlatif55

import UIKit

class ___FILEBASENAMEASIDENTIFIER___: UIViewController {
    
    // MARK: - Outlets
    
    // MARK: - Variables
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .primaryBg
        setupUI()
    }
    
    private func setupUI(){
        
    }
    
    
}

// MARK: - Actions
extension ___FILEBASENAMEASIDENTIFIER___ {
    
}

// MARK: - Methods
extension ___FILEBASENAMEASIDENTIFIER___ {
    
}

// MARK: - ViewModel
extension ___FILEBASENAMEASIDENTIFIER___ {
    
}
